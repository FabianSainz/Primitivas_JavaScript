function figtotal(){
    var num = document.getElementById("numeros").value;
    var r = document.getElementsByName("opcion");
    var op = document.getElementsByName("forma");

    html="";

    for(var i=0; i< r.length; i++){
        if(op[i].checked){
            var f = op[i].value;
        }
    }
    switch(f){
        case 'cu':
            for(var i=0; i< r.length; i++){
                if(r[i].checked){
                    var e = r[i].value;
                }
            }
            switch(e){
                case 'a':
                    for(var i = 0; i < num;i++){
                        html += "<div style='height: 50px; width:50px; background:yellow; display: inline-block; margin: 5px;'></div>";
                    }
                
                    document.getElementById("resultado").innerHTML = html;
                break;
        
                case 'b':
                    for(var i = 0; i < num;i++){
                        html += "<div style='height: 50px; width:50px; background:white; display: inline-block; margin: 5px;'></div>" 
                    }
                
                    document.getElementById("resultado").innerHTML = html;
                break;
        
              
            }
        break;

        case 'ci':
            for(var i=0; i< r.length; i++){
                if(r[i].checked){
                    var e = r[i].value;
                }
            }
            switch(e){
                case 'a':
                    for(var i = 0; i < num;i++){
                        html += "<div style='height: 50px; width:50px; background:yellow; display: inline-block; margin: 5px; -moz-border-radius: 50%; -webkit-border-radius: 50%; border-radius: 50%;'></div>" 
                    }
                
                    document.getElementById("resultado").innerHTML = html;
                break;
        
                case 'b':
                    for(var i = 0; i < num;i++){
                        html += "<div style='height: 50px; width:50px; background:white; display: inline-block; margin: 5px; -moz-border-radius: 50%; -webkit-border-radius: 50%; border-radius: 50%;'></div>" 
                    }
                
                    document.getElementById("resultado").innerHTML = html;
                break;
        
               
            }
      
          
        }
    


   
}