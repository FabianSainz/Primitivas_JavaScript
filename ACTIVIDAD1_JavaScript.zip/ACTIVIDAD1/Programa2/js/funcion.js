function mostrarDatos(){


    var m = document.getElementsByName("helado");
    for(var i=0; i< m.length; i++){
        if(m[i].checked){
            var music = m[i].value;
        }
    }
    var p = document.getElementsByName("musica");
    for(var i=0; i< p.length; i++){
        if(p[i].checked){
            var pelis = p[i].value;
        }
    }
    var s = document.getElementsByName("marca");
    for(var i=0; i< s.length; i++){
        if(s[i].checked){
            var sis = s[i].value;
        }
    }
    var e = document.getElementsByName("pais");
    for(var i=0; i< e.length; i++){
        if(e[i].checked){
            var esta = e[i].value;
        }
    }
    var c = document.getElementsByName("color");
    for(var i=0; i< c.length; i++){
        if(c[i].checked){
            var col = c[i].value;
        }
    }
    

    datos = '*Tu sabor de helado es : '+music+'<br/>*Tu género de musica es : '+pelis+'<br/>*Tu marca preferida es : '+sis+'<br/>*Tu pais favorito es : '+esta+'<br/>*Tu color favorito es : '+col;
    document.getElementById("resultado").innerHTML = datos;

}